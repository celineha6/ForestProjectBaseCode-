# CPE/CSC 203 Project

Hello! This is the project we'll be playing with all quarter.
You should load this into IntelliJ IDEA using the same procedure
that you use for labs.

Instructions for the project will be in a Canvas assignment.

_You're encouraged to frequently commit and push your changes
to GitHub!_

The nature of this project is that you are necessarily introducing
(temporary) syntax errors as you refactor the code-base. It's possible
that you will make a mistake and want to go back to before you made
certain changes. Git will help you do that, but only if you've 
frequently committed versions of the project.

<div style="color: darkgreen;">All the best!</div>